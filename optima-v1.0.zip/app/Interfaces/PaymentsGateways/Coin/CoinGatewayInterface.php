<?php

namespace App\Interfaces\PaymentsGateways\Coin;

interface CoinGatewayInterface
{

}
