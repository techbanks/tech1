<?php

namespace App\Interfaces\User;

interface UserRepositoryInterface
{

}
